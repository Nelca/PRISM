(() => {
  const cases = {
    cross: { low: -8, high: 18, label: '前提の確認が必要', title: '結論を左右する\n前提を、確かめる。', body: '評価の幅が承認基準をまたぐ場合、採用する前提によって判断が変わり得ます。追加調査すべき論点を絞ります。', action: '主要な前提と不足データを確認', color: '#adbd8e', description: '承認基準の0をまたぎます。' },
    above: { low: 8, high: 22, label: 'この試算範囲では基準を上回る', title: '進める理由を、\n根拠とともに残す。', body: '評価の幅全体が承認基準を上回るケースです。採用した前提を記録し、他の承認条件と合わせて投資の検討を進めます。', action: '他の承認条件を確認し、判断理由を記録', color: '#64856e', description: '全体が承認基準の0を上回ります。' },
    below: { low: -18, high: -4, label: 'この試算範囲では基準を下回る', title: '対策の条件を、\n見直す材料に。', body: '評価の幅全体が承認基準を下回るケースです。費用や施策の条件を見直します。法令対応など、NPV以外の必要性は別途検討します。', action: '対策案・費用・財務以外の必要性を検討', color: '#a5a391', description: '全体が承認基準の0を下回ります。' }
  };
  const signed = n => n < 0 ? '−' + Math.abs(n) : '+' + n;
  document.querySelectorAll('[data-case]').forEach(button => button.addEventListener('click', () => {
    const item = cases[button.dataset.case];
    document.querySelectorAll('[data-case]').forEach(b => b.setAttribute('aria-pressed', String(b === button)));
    const bar = document.getElementById('range-bar');
    bar.style.left = ((item.low + 30) / 60 * 100) + '%';
    bar.style.width = ((item.high - item.low) / 60 * 100) + '%';
    bar.style.background = item.color;
    document.getElementById('range-low').textContent = signed(item.low);
    document.getElementById('range-high').textContent = signed(item.high);
    document.getElementById('verdict-label').textContent = item.label;
    document.getElementById('verdict-title').replaceChildren(...item.title.split('\n').flatMap((text, i) => i ? [document.createElement('br'), document.createTextNode(text)] : [document.createTextNode(text)]));
    document.getElementById('verdict-body').textContent = item.body;
    document.getElementById('next-action').textContent = item.action;
    document.getElementById('range-chart').setAttribute('aria-label', `NPVの幅は${item.low}から${item.high}百万円。${item.description}`);
  }));
  const contact = window.PRISM_PROMOTION?.contactUrl;
  if (contact) {
    try {
      const url = new URL(contact);
      if (url.protocol !== 'https:') return;
      const link = document.getElementById('contact-link');
      link.href = url.href;
      link.removeAttribute('download');
      link.textContent = '検証について相談する ↗';
      document.getElementById('contact-note').textContent = '相談窓口へ移動します。対象案件や検討状況をお聞かせください。';
    } catch { /* 設定不備では資料ダウンロードを維持する。 */ }
  }
})();
